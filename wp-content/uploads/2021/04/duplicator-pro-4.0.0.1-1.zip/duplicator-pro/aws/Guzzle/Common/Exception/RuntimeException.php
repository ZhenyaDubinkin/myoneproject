<?php
namespace DuplicatorPro\Guzzle\Common\Exception;

defined("ABSPATH") or die("");

class RuntimeException extends \RuntimeException implements GuzzleException {}
